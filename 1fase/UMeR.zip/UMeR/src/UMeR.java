
/**
 * Write a description of class UMeR here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.util.Map;
import java.util.HashMap;
import java.lang.StringBuilder;
import java.time.LocalDate;
import java.io.Serializable;

public class UMeR implements Serializable
{
    /*
    private HashMap<int, Client> clientList;
    private HashMap<int, Driver> driverList;
    private HashMap<String, ? extends Vehicle> vehicleList;
    private HashMap<int, Trip> tripList;

    public static UMeR(){

    }
    */
}
